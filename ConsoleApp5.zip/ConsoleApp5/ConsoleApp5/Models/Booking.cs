﻿using ConsoleApp5.Enums;

namespace ConsoleApp5.Models
{
    internal class Booking
    {
        public int Id { get; set; }
        public DateTime BookingDate { get; set; }
        public BookingType bookingType { get; set; } = BookingType.Pending;
        public int UserId { get; set; }
        public User User { get; set; }
        public int ServiceID { get; set; }
        public Service Service { get; set; }

    }
}
