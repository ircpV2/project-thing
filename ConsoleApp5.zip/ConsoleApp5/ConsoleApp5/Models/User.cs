﻿namespace ConsoleApp5.Models
{
    internal class User
    {


        public int Id { get; set; }
        public string Name { get; set; }
        public string Email { get; set; }
        public int Age { get; set; }
        public string Password { get; set; }
        public bool isVerified { get; set; } = false;
        public string? Code { get; set; } = null;

        public User(int id, string name, string email, int age, string password, bool isVerified, string? code)
        {
            Id = id;
            Name = name;
            Email = email;
            Age = age;
            Password = password;
            this.isVerified = isVerified;
            Code = code;
        }

    }
}
