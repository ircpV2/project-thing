﻿using ConsoleApp5.Enums;

namespace ConsoleApp5.Models
{
    internal class Service
    {

        public int Id { get; set; }
        public Category Category { get; set; } = Category.Other;
        public decimal Price { get; set; }
        public int DurationMinutes { get; set; }
        public string Description { get; set; }
        public bool IsShipable { get; set; }

        public Service(int id, Category category, decimal price, int durationMinutes, string description, bool isShipable)
        {
            Id = id;
            Category = category;
            Price = price;
            DurationMinutes = durationMinutes;
            Description = description;
            IsShipable = isShipable;
        }

    }
}
