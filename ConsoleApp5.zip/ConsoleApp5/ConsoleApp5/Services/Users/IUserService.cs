﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ConsoleApp5.Services.Users
{
    internal class IUserService
    {
    }
}
