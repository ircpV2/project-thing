﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ConsoleApp5.Services.Bookings
{
    internal class BookingService
    {
    }
}
