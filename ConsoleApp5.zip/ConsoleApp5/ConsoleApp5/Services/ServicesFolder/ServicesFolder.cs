﻿using ConsoleApp5.Models;

namespace ConsoleApp5.Services.ServicesFolder
{
    internal class ServicesFolder : IServicesFolder
    {
        string path = "C:\\Users\\student\\source\\repos\\ConsoleApp5\\ConsoleApp5\\Data\\Service.txt";
        public bool AddService(Service service)
        {
            throw new NotImplementedException();
        }

        public void DeleteService(int Id)
        {
            throw new NotImplementedException();
        }

        public Service GetService(int Id)
        {
            throw new NotImplementedException();
        }

        public List<Service> GetServices(List<Service> services)
        {
            throw new NotImplementedException();
        }
    }
}
