﻿using ConsoleApp5.Models;

namespace ConsoleApp5.Services.ServicesFolder
{
    internal interface IServicesFolder
    {
        public bool AddService(Service service);
        public Service GetService(int Id);
        public List<Service> GetServices(List<Service> services);
        public void DeleteService(int Id);

    }
}
