﻿namespace ConsoleApp5.Enums
{
    internal enum Category
    {
        software,
        hardware,
        Telephone,
        Xerox,
        Photo,
        Other
    }
}
