﻿namespace ConsoleApp5.Enums
{
    internal enum BookingType
    {
        Cancelled,
        Done,
        Approved,
        Pending
    }
}
